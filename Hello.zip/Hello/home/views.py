from django.shortcuts import render, HttpResponse, redirect
from datetime import datetime
from .models import Contact
from .models import Article
from django.views.generic import DetailView
from django.contrib import messages
from django.contrib.auth.models import User, auth

# Create your views here.
def index(request):
	
	#return HttpResponse ('this is home page')
	article = Article.objects.all()
	return render(request, 'index.html', {'article': article})

def about(request):
	#return HttpResponse ('this is about page')
	return render(request, 'about.html',)

def services(request):
	#return HttpResponse ('this is services page')
	return render(request, 'services.html',)

def contact(request):
	#return HttpResponse ('this is contact page')
	if request.method == "POST":
		name = request.POST.get('name')
		email = request.POST.get('email')
		phone = request.POST.get('phone')
		desc = request.POST.get('desc')
		contact = Contact(name=name, email=email, phone=phone, desc=desc, date=datetime.today())
		contact.save()
		messages.success(request, 'Your massage has successfully sent!!!')
		
	return render(request, 'contact.html',)

#def detail(request):
	#return HttpResponse ('this is detail page')
	#return render(request, 'detail.html',)


class ArticleDetailView(DetailView):
	model = Article
	template_name = 'detail.html'
	context_object_name = 'batman'

def register(request):
	#return HttpResponse ('this is about page')

	if request.method=='POST':
		first_name = request.POST['first_name']
		last_name = request.POST['last_name']
		username = request.POST['username']
		email = request.POST['email']
		password1 = request.POST['password1']
		password2 = request.POST['password2']

		if password1==password2:
			if User.objects.filter(username=username).exists():
				messages.success(request, 'Username already exists !!!')
				return redirect('register')
			elif User.objects.filter(email=email).exists():
				messages.success(request, 'email has already taken !!!')
				return redirect('register')
			else:
				user = User.objects.create_user(username=username, password=password1, email=email, first_name=first_name, last_name=last_name)
				user.save();
				messages.success(request, 'You have successfully register yourself !!!')
				return redirect('login')
		
		else:
			messages.success(request, 'Password is not matched !!!')
			return redirect('register')
		return redirect('/')
	else:
		return render(request, 'register.html',)


def login(request):
	#return HttpResponse ('this is about page')
	if request.method== 'POST':
		username = request.POST['username']
		password = request.POST['password']

		user = auth.authenticate(username=username, password=password)

		if user is not None:
			auth.login(request, user)
			return redirect ('/')

		else:
			messages.success(request, 'invalid credentials !!!')
			return redirect ('login')


	else:
		return render(request, 'login.html',)


def logout(request):
	auth.logout(request)
	return redirect('/')
